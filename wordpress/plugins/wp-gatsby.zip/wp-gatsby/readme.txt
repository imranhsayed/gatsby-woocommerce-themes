=== WPGatsby ===
Contributors: gatsbyinc, jasonbahl, tylerbarnes1
Tags: Gatsby, GatsbyJS, JavaScript, JAMStack, Static Site generator, GraphQL, Headless WordPress, Decoupled WordPress
Requires at least: 5.4.2
Tested up to: 5.6
Requires PHP: 7.3
Stable tag: 0.9.1
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

This plugin configures your WordPress site to be an optimized source for Gatsby.
See https://github.com/gatsbyjs/gatsby-source-wordpress-experimental for more info.
