<?php // phpcs:ignore Internal.NoCodeFound ?>
{{block name="yoast/step" title="Step" category="common" parent=["yoast/steps"]}}
<li class={{class-name}}>
	{{inner-blocks allowed-blocks=[ "core/heading", "core/paragraph", "core/image" ] }}
</li>
